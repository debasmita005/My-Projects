﻿using DemoPizza.Models;
using Microsoft.EntityFrameworkCore;

namespace DemoPizza.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        // DbSet properties for all models
        public DbSet<User> Users { get; set; }
        public DbSet<Pizza> Pizzas { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<ContactForm> ContactForms { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure relationships, constraints, and default values here

            // User-Order relationship: One-to-many (User -> Orders)
            modelBuilder.Entity<Order>()
                .HasOne(o => o.User)
                .WithMany(u => u.Orders)
                .HasForeignKey(o => o.UserId)
                .OnDelete(DeleteBehavior.Cascade); // Cascade delete when a user is deleted

            // Order-OrderItem relationship: One-to-many (Order -> OrderItems)
            modelBuilder.Entity<OrderItem>()
                .HasOne(oi => oi.Order)
                .WithMany(o => o.OrderItems)
                .HasForeignKey(oi => oi.OrderId)
                .OnDelete(DeleteBehavior.Cascade); // Cascade delete when an order is deleted

            // Pizza-OrderItem relationship: One-to-many (Pizza -> OrderItems)
            modelBuilder.Entity<OrderItem>()
                .HasOne(oi => oi.Pizza)
                .WithMany(p => p.OrderItems)
                .HasForeignKey(oi => oi.PizzaId)
                .OnDelete(DeleteBehavior.Cascade); // Cascade delete when a pizza is deleted

            // Enum conversions
            modelBuilder.Entity<Order>()
                .Property(o => o.OrderStatus)
                .HasConversion<int>(); // Store enum as integer

            modelBuilder.Entity<Order>()
                .Property(o => o.PaymentMethod)
                .HasConversion<int>(); // Store enum as integer

            modelBuilder.Entity<Pizza>()
                .Property(p => p.Category)
                .HasConversion<int>(); // Store enum as integer

            modelBuilder.Entity<User>()
                .Property(u => u.Role)
                .HasConversion<int>(); // Store enum as integer

            // Default values
            modelBuilder.Entity<User>()
                .Property(u => u.Role)
                .HasConversion(
                    v => v.ToString(),
                    v => (Role)Enum.Parse(typeof(Role), v))
                .HasDefaultValue(Role.User); // Default role is User
        }
    }
}
