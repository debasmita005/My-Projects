﻿using DemoPizza.Data;
using DemoPizza.Models;
using DemoPizza.Repository.Interfaces;
using DemoPizza.Services;
using System.Collections.Generic;
using System.Linq;

namespace DemoPizza.Repository.Implementations
{
    public class PizzaRepository : IPizzaServices
    {
        private readonly AppDbContext _context;

        public PizzaRepository(AppDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Pizza> GetAll()
        {
            return _context.Pizzas.ToList();
        }

        public Pizza GetById(int id)
        {
            return _context.Pizzas.FirstOrDefault(p => p.PizzaId == id);
        }

        public void Add(Pizza pizza)
        {
            _context.Pizzas.Add(pizza);
            _context.SaveChanges();
        }

        public void Update(Pizza pizza)
        {
            _context.Pizzas.Update(pizza);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var pizza = _context.Pizzas.FirstOrDefault(p => p.PizzaId == id);
            if (pizza != null)
            {
                _context.Pizzas.Remove(pizza);
                _context.SaveChanges();
            }
        }
    }
}