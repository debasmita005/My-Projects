﻿using DemoPizza.Models;

namespace DemoPizza.Repository.Interfaces
{
    public interface IPizzaRepository
    {
        IEnumerable<Pizza> GetAll();
        Pizza GetById(int id);
        void Add(Pizza pizza);
        void Update(Pizza pizza);
        void Delete(int id);
    }
}
