﻿using DemoPizza.Models;

namespace DemoPizza.Repository.Interfaces
{
    public interface IOrderRepository
    {
        IEnumerable<Order> GetAll();
        Order GetById(int id);
        IEnumerable<Order> GetByUserId(int userId);
        void Add(Order order);
        void Update(Order order);
        void Delete(int id);
    }
}
