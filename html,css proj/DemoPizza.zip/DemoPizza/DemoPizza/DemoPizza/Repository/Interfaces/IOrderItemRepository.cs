﻿using DemoPizza.Models;

namespace DemoPizza.Repository.Interfaces
{
    public interface IOrderItemRepository
    {
        IEnumerable<OrderItem> GetByOrderId(int orderId);
        void Add(OrderItem orderItem);
        void Update(OrderItem orderItem);
        void Delete(int id);
    }
}
