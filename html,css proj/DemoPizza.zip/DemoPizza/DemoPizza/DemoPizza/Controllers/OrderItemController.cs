﻿using DemoPizza.Models;
using DemoPizza.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace DemoPizza.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderItemController : Controller
    {
        private readonly IOrderItemRepository _orderItemRepository;

        public OrderItemController(IOrderItemRepository orderItemRepository)
        {
            _orderItemRepository = orderItemRepository;
        }

        [HttpPost]
        public IActionResult AddOrderItem(OrderItem orderItem)
        {
            _orderItemRepository.Add(orderItem);
            return Ok("Order item added successfully.");
        }

        [HttpGet("{orderId}")]
        public IActionResult GetOrderItemsByOrder(int orderId)
        {
            var orderItems = _orderItemRepository.GetByOrderId(orderId);
            return Ok(orderItems);
        }
    }
}
