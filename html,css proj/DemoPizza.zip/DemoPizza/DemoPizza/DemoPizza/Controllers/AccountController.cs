using DemoPizza.Models;
using DemoPizza.Repository.Interfaces;
using DemoPizza.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;

namespace DemoPizza.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUserRepository _userRepository;
        private readonly IAccountService _accountService;

        public AccountController(IAccountService accountService)
        {
            _accountService = accountService;
        }


        public IActionResult Register()
        {
            return View();
        }

        [HttpPost("register")]
        public IActionResult Register(User user)
        {
            var result = _accountService.Register(user);
            if (!result)
                return BadRequest("Registration failed.");
            return Ok("User registered successfully.");
        }

        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Admin()
        {
            return View();
        }
        public IActionResult UserHomePage()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(Login model)
        {
            if (!ModelState.IsValid)
            {
                return View(model); // Return to the login view if validation fails
            }

            // Use the injected _userRepository instance to call Login
            var user = _accountService.Login(model.Email, model.Password);

            if (user == null || string.IsNullOrEmpty(user.Password))
            {
                ModelState.AddModelError("", "Invalid email or password");
                return View(model);
            }

            // Check the role of the user and redirect accordingly
            // Check the role of the user and redirect accordingly
            if (user.Role == Role.Admin)
            {
                return RedirectToAction("Admin", "Account");
            }
            else if (user.Role == Role.User)
            {
                return RedirectToAction("UserHomePage", "Account");
            }
            else
            {
                return RedirectToAction("Index", "Account");
            }
        }
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Account");
        }

    }
}
