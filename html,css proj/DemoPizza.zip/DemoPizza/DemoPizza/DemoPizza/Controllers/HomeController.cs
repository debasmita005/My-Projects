using DemoPizza.Models;
using Microsoft.AspNetCore.Mvc;
using DemoPizza.Data;

namespace DemoPizza.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;

        public HomeController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Contact()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Contact(ContactFormModel model)
        {
            if (ModelState.IsValid)
            {
                var contactForm = new ContactForm
                {
                    Name = model.Name,
                    Email = model.Email,
                    Message = model.Message
                };
                _context.ContactForms.Add(contactForm);
                _context.SaveChanges();

                ViewBag.Message = "Thank you for contacting us!";
                return View();
            }

            // If the model state is invalid, return the same view with validation messages.
            return View(model);
        }
    }
}