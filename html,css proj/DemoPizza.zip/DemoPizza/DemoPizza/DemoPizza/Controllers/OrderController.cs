﻿using DemoPizza.Models;
using DemoPizza.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace DemoPizza.Controllers
{
    [ApiController]
    [Route("api/orders")] // Base route for the controller
    public class OrderController : Controller
    {
        private readonly IOrderRepository _orderRepository;

        public OrderController(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        // Action to get orders by user
        [HttpGet("user/{userId}")] // Route: api/Order/user/{userId}
        public IActionResult GetOrdersByUser(int userId)
        {
            var orders = _orderRepository.GetByUserId(userId);
            return Ok(orders);
        }

        // Action to place an order
        [HttpPost("place")] // Route: api/Order/place
        public IActionResult PlaceOrder([FromBody] Order order)
        {
            _orderRepository.Add(order);
            return Ok("Order placed successfully.");
        }
    }
}
