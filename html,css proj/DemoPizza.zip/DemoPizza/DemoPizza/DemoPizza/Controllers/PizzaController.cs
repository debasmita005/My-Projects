﻿using DemoPizza.Models;
using DemoPizza.Repository.Interfaces;
using DemoPizza.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;

namespace DemoPizza.Controllers
{
    public class PizzaController : Controller
    {
        private readonly IPizzaServices _pizzaServices;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public PizzaController(IPizzaServices pizzaServices, IWebHostEnvironment webHostEnvironment)
        {
            _pizzaServices = pizzaServices;
            _webHostEnvironment = webHostEnvironment;
        }

        [HttpGet]
        public IActionResult GetAllPizzas()
        {
            var pizzas = _pizzaServices.GetAll();
            return View(pizzas);
        }

        [HttpGet("{id}")]
        public IActionResult GetPizzaById(int id)
        {
            var pizza = _pizzaServices.GetById(id);
            if (pizza == null)
            {
                return NotFound();
            }
            return Ok(pizza);
        }



        [HttpPost]
        public async Task<IActionResult> CreatePizza(string Name, string Description, decimal Price, IFormFile Image)
        {
            if (Image != null && Image.Length > 0)
            {
                var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images");
                var uniqueFileName = Guid.NewGuid().ToString() + "_" + Image.FileName;
                var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await Image.CopyToAsync(fileStream);
                }

                var pizza = new Pizza
                {
                    Name = Name,
                    Description = Description,
                    Price = Price,
                    ImageUrl = "/images/" + uniqueFileName
                };

                _pizzaServices.Add(pizza);

                return RedirectToAction("Admin", "Account");
            }

            return BadRequest("Invalid data.");
        }
        [HttpPut("{id}")]
        public IActionResult UpdatePizza(int id, Pizza pizza)
        {
            if (pizza == null || pizza.PizzaId != id)
            {
                return BadRequest("Pizza is null or ID mismatch.");
            }

            var existingPizza = _pizzaServices.GetById(id);
            if (existingPizza == null)
            {
                return NotFound();
            }

            _pizzaServices.Update(pizza);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePizza(int id)
        {
            var pizza = _pizzaServices.GetById(id);
            if (pizza == null)
            {
                return NotFound();
            }

            _pizzaServices.Delete(id);
            return NoContent();
        }

        // Action for displaying the Create Pizza view
        [HttpGet]
        public IActionResult CreatePizza()
        {
            return View();
        }

        // Action for displaying the Update Pizza view
        [HttpGet]
        public IActionResult EditPizza(int id)
        {
            var pizza = _pizzaServices.GetById(id);
            if (pizza == null)
            {
                return NotFound();
            }
            return View(pizza);
        }
    }
}