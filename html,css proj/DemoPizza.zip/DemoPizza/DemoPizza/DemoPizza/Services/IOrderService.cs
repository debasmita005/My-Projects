﻿using DemoPizza.Models;
using System.Collections.Generic;

namespace DemoPizza.Services.Interfaces
{
    public interface IOrderService
    {
        IEnumerable<Order> GetAll();
        Order GetById(int id);
        IEnumerable<Order> GetByUserId(int userId);
        void Add(Order order);
        void Update(Order order);
        void Delete(int id);
    }
}