﻿using DemoPizza.Models;

namespace DemoPizza.Services
{
    public interface IAccountService
    {
        bool Register(User user);
        User Login(string email, string password);
    }
}
