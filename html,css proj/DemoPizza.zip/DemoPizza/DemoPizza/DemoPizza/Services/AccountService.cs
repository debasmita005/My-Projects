﻿using DemoPizza.Models;
using DemoPizza.Repository.Interfaces;

namespace DemoPizza.Services
{
    public class AccountService : IAccountService
    {
        private readonly IUserRepository _userRepository;

        public AccountService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public bool Register(User user)
        {
            if (_userRepository.GetByEmail(user.Email) != null)
                return false; // Email already exists

            user.Password = BCrypt.Net.BCrypt.HashPassword(user.Password);
            _userRepository.Add(user);
            return true;
        }

        public User Login(string email, string password)
        {
            var user = _userRepository.GetByEmail(email);
            if (user != null && BCrypt.Net.BCrypt.Verify(password, user.Password))
                return user;

            return null;
        }
    }
}
