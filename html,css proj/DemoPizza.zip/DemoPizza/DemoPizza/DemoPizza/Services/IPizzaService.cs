﻿using DemoPizza.Models;
using System.Collections.Generic;

namespace DemoPizza.Repository.Interfaces
{
    public interface IPizzaServices
    {
        IEnumerable<Pizza> GetAll();
        Pizza GetById(int id);
        void Add(Pizza pizza);
        void Update(Pizza pizza);
        void Delete(int id);
    }
}